import tkinter as tk
from tkinter import messagebox
import mysql.connector
 
# ──────────────────────────────────────────────
# CONEXIÓN A MySQL
# ──────────────────────────────────────────────
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",        # <-- cambia por tu contraseña
        database="crud_app"
    )
 
# ──────────────────────────────────────────────
# FUNCIONES CRUD
# ──────────────────────────────────────────────
def add_user():
    name      = entry_name.get().strip()
    apellido  = entry_apellido.get().strip()
    email     = entry_email.get().strip()
    telefono  = entry_telefono.get().strip()
    direccion = entry_direccion.get().strip()
    ocupacion = entry_ocupacion.get().strip()
 
    if name and apellido and email:
        conn   = connect_db()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (name, apellido, email, telefono, direccion, ocupacion) "
            "VALUES (%s, %s, %s, %s, %s, %s)",
            (name, apellido, email, telefono, direccion, ocupacion)
        )
        conn.commit()
        conn.close()
        fetch_users()
        clear_fields()
    else:
        messagebox.showwarning("Error de entrada", "Nombre, Apellido y Email son obligatorios.")
 
 
def fetch_users():
    listbox.delete(0, tk.END)
    conn   = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users")
    for row in cursor.fetchall():
        listbox.insert(
            tk.END,
            f"{row[0]} - {row[1]} {row[2]} - {row[3]} - {row[4]} - {row[5]} - {row[6]}"
        )
    conn.close()
 
 
def delete_user():
    selected = listbox.get(tk.ACTIVE)
    if selected:
        user_id = selected.split(" - ")[0]
        conn    = connect_db()
        cursor  = conn.cursor()
        cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
        conn.commit()
        conn.close()
        fetch_users()
        clear_fields()
    else:
        messagebox.showwarning("Selección vacía", "Selecciona un usuario de la lista.")
 
 
def update_user():
    selected = listbox.get(tk.ACTIVE)
    if not selected:
        messagebox.showwarning("Selección vacía", "Selecciona un usuario de la lista.")
        return
 
    user_id   = selected.split(" - ")[0]
    name      = entry_name.get().strip()
    apellido  = entry_apellido.get().strip()
    email     = entry_email.get().strip()
    telefono  = entry_telefono.get().strip()
    direccion = entry_direccion.get().strip()
    ocupacion = entry_ocupacion.get().strip()
 
    if name and apellido and email:
        conn   = connect_db()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE users SET name=%s, apellido=%s, email=%s, "
            "telefono=%s, direccion=%s, ocupacion=%s WHERE id=%s",
            (name, apellido, email, telefono, direccion, ocupacion, user_id)
        )
        conn.commit()
        conn.close()
        fetch_users()
        clear_fields()
    else:
        messagebox.showwarning("Error de entrada", "Nombre, Apellido y Email son obligatorios.")
 
 
def fill_form_from_selection(event):
    selected = listbox.get(tk.ACTIVE)
    if selected:
        parts = selected.split(" - ")
        # parts: [id, nombre apellido, email, telefono, direccion, ocupacion]
        nombre_apellido = parts[1].split(" ", 1) if len(parts) > 1 else ["", ""]
        clear_fields()
        entry_name.insert(tk.END, nombre_apellido[0])
        entry_apellido.insert(tk.END, nombre_apellido[1] if len(nombre_apellido) > 1 else "")
        entry_email.insert(tk.END,     parts[2] if len(parts) > 2 else "")
        entry_telefono.insert(tk.END,  parts[3] if len(parts) > 3 else "")
        entry_direccion.insert(tk.END, parts[4] if len(parts) > 4 else "")
        entry_ocupacion.insert(tk.END, parts[5] if len(parts) > 5 else "")
 
 
def clear_fields():
    for entry in (entry_name, entry_apellido, entry_email,
                  entry_telefono, entry_direccion, entry_ocupacion):
        entry.delete(0, tk.END)
 
# ──────────────────────────────────────────────
# INTERFAZ GRÁFICA (GUI)
# ──────────────────────────────────────────────
root = tk.Tk()
root.title("CRUD App with MySQL")
root.resizable(False, False)
 
# --- Etiquetas y campos ---
labels = ["Nombre:", "Apellido:", "Email:", "Teléfono:", "Dirección:", "Ocupación:"]
for i, text in enumerate(labels):
    tk.Label(root, text=text, anchor="w", width=10).grid(
        row=i, column=0, padx=(10, 2), pady=5, sticky="w"
    )
 
entry_name      = tk.Entry(root, width=35)
entry_apellido  = tk.Entry(root, width=35)
entry_email     = tk.Entry(root, width=35)
entry_telefono  = tk.Entry(root, width=35)
entry_direccion = tk.Entry(root, width=35)
entry_ocupacion = tk.Entry(root, width=35)
 
entries = [entry_name, entry_apellido, entry_email,
           entry_telefono, entry_direccion, entry_ocupacion]
 
for i, entry in enumerate(entries):
    entry.grid(row=i, column=1, columnspan=2, padx=(2, 10), pady=5)
 
# --- Botones ---
btn_row = len(labels)
tk.Button(root, text="Agregar",    width=12, bg="#4CAF50", fg="white",
          command=add_user).grid(row=btn_row, column=0, pady=10, padx=5)
tk.Button(root, text="Actualizar", width=12, bg="#2196F3", fg="white",
          command=update_user).grid(row=btn_row, column=1, pady=10, padx=5)
tk.Button(root, text="Eliminar",   width=12, bg="#f44336", fg="white",
          command=delete_user).grid(row=btn_row, column=2, pady=10, padx=5)
 
# --- Listbox con scrollbar ---
frame_list = tk.Frame(root)
frame_list.grid(row=btn_row+1, column=0, columnspan=3, padx=10, pady=(0, 10))
 
scrollbar = tk.Scrollbar(frame_list, orient=tk.VERTICAL)
listbox   = tk.Listbox(frame_list, width=70, height=10,
                       yscrollcommand=scrollbar.set)
scrollbar.config(command=listbox.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
listbox.pack(side=tk.LEFT, fill=tk.BOTH)
 
listbox.bind("<<ListboxSelect>>", fill_form_from_selection)
 
# --- Cargar datos al iniciar ---
fetch_users()
 
root.mainloop()