-- Paso 1: Crear la base de datos
CREATE DATABASE IF NOT EXISTS crud_app;
USE crud_app;
 

 CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
     email VARCHAR(100)
      );
 

CREATE TABLE IF NOT EXISTS users (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    name      VARCHAR(100),
    apellido  VARCHAR(100),
    email     VARCHAR(100),
    telefono  VARCHAR(20),
    direccion VARCHAR(200),
    ocupacion VARCHAR(100)
);
 