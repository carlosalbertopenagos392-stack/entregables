public class sumaMdeiaArrayApp {
    
    public static void main(String[] args) {

        //creo un array
        int[] numeros=new int[100];

        //declaro las variables necesarias
        int suma=0;
        double media;

        //recorro el array, asigno numeros y sumo
        for(int i=0;i<numeros.length;i++){
            numeros[i]=i+1;
            suma+=numeros[i];
        }

        //calculo la media y muestro la suma y la meda
        System.out.println("la suma es "+suma);

        media=(double)suma/numeros.length;

        System.out.println("la media es "+media);

    }
    
}   