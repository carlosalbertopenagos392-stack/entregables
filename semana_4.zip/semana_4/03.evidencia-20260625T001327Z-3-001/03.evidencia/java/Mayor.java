import javax.swing.JOptionPane;

public class Mayor{

    public static void main(String[] args) {

            //indicamos el tamaño
            String texto=JOptionPane.showInputDialog("Introduce un tamaño");
            int num[]=new int[Integer.parseInt(texto)];

            //Invocamos las funciones
            rellenarNumPrimosAleatorioArray(num, 1, 100);

            mostrarArray(num);

            //saco el primo mayor
            int primoMayor=mayor(num);
                System.out.println("el primo mas grande es el "+primoMayor);
        }

    public static void rellenarNumPrimosAleatorioArray(int lista[], int a, int b){

        int i=0;

        //usamos mejor while, ya que solo aumentara cuando genere un primo
        while(i<lista.length){
            int num=((int)Math.floor(Math.random()*(a-b)+b));
            if (esPrimo(num)){
                lista[1]=num;
                i++;
            }
        }
    }
    private static boolean esPrimo (int num){

        //un numero negativo, el 0 y el 1, son directamente no primos.
        if (num<=1){
            return false;
        }else{

            //declaracion
            int prueba;
            int contador=0;
            //hacemos la raiz cuadrada y lo usamos para dividir el numero original
            prueba=(int)Math.sqrt(num);
            //bucle que cuenta los numeros divisibles, podemos hacerlo con while
            for (;prueba>1;prueba--){
                if (num%prueba==0){
                    contador++;
                }
            }
            return contador < 1;
        }
    }

    public static void mostrarArray(int lista[]){
        for(int i=0;i<lista.length;i++){
                System.out.println("en el indice "+i+ " esta el valor "+lista[i]);
        }
    }

    public static int mayor(int lista[]){
        int mayor=0;
        for(int i =0;i<lista.length;i++){
            if(lista[i]>mayor){
                mayor=lista[i];
            }
        }

        return mayor;
    }

    }