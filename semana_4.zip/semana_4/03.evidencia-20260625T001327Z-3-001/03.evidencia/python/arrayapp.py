def rellenar_array(lista):
    for i in range(len(lista)):
        lista[i] = int(input("Introduce un número: "))

def mostrar_array(lista):
    for i in range(len(lista)):
        print(f"En el índice {i} está el valor {lista[i]}")

# Esto es opcional
TAMANIO = 5

# Crear lista con 5 posiciones
num = [0] * TAMANIO
