import random
import math

def es_primo(num):
    # Un número negativo, 0 y 1 no son primos
    if num <= 1:
        return False

    prueba = int(math.sqrt(num))

    while prueba > 1:
        if num % prueba == 0:
            return False
        prueba -= 1

    return True

def rellenar_num_primos_aleatorio_array(lista, a, b):
    i = 0

    # Solo aumenta cuando genera un primo
    while i < len(lista):
        num = random.randint(a, b)

        if es_primo(num):
            lista[i] = num
            i += 1

def mostrar_array(lista):
    for i in range(len(lista)):
        print(f"En el índice {i} está el valor {lista[i]}")

def mayor(lista):
    mayor = lista[0]

    for i in range(len(lista)):
        if lista[i] > mayor:
            mayor = lista[i]

    return mayor

# Programa principal
tamano = int(input("Introduce un tamaño: "))

num = [0] * tamano

# Invocar funciones
rellenar_num_primos_aleatorio_array(num, 1, 100)

mostrar_array(num)

# Sacar el primo mayor
primo_mayor = mayor(num)

print(f"El primo más grande es {primo_mayor}")