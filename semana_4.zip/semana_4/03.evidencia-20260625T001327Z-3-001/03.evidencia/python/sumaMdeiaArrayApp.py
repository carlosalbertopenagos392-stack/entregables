numeros = list(range(1, 101))

suma = sum(numeros)
media = suma / len(numeros)

print("La suma es", suma)
print("La media es", media)