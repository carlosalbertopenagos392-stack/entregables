$(document).ready(function(){

    // Localización en español del datepicker
    $.datepicker.regional['es'] = {
        closeText: 'Cerrar',
        prevText: '&#x3C;Ant',
        nextText: 'Sig&#x3E;',
        currentText: 'Hoy',
        monthNames: ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
                     'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'],
        monthNamesShort: ['Ene','Feb','Mar','Abr','May','Jun',
                          'Jul','Ago','Sep','Oct','Nov','Dic'],
        dayNames: ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'],
        dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
        dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
        weekHeader: 'Sm',
        dateFormat: 'yy-mm-dd',
        firstDay: 1,              // La semana empieza en lunes
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: ''
    };
    $.datepicker.setDefaults($.datepicker.regional['es']);

    $(".datepicker").datepicker({
        dateFormat: 'yy-mm-dd',
        changeMonth: true,        // Selector de mes
        changeYear: true,         // Selector de año
        yearRange: '-100:+0',     // Hasta el año actual (útil para fechas de nacimiento)
        showOtherMonths: true,    // Muestra días de meses adyacentes
        selectOtherMonths: true,  // Permite seleccionarlos
        showButtonPanel: true,    // Panel con botón "Hoy"
        maxDate: new Date(),      // No permite fechas futuras (nacimiento)
        beforeShow: function(input) {
            // Añade clase al input para alineación del popup
            setTimeout(function() {
                $('#ui-datepicker-div').addClass('calendar-styled');
            }, 0);
        }
    });

    // Abrir calendario al hacer clic en el ícono también
    $('.icono-calendario').on('click', function(){
        $(this).siblings('.datepicker').datepicker('show');
    });

});
