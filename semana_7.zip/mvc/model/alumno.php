<?php
class Alumno
{
	private $pdo;
    
    public $id;
    public $Nombre;
    public $Apellido;
    public $Sexo;
    public $FechaRegistro;
    public $FechaNacimiento;
    public $Foto;
    public $Correo;

	public function __CONSTRUCT()
	{
		try
		{
			$this->pdo = Database::StartUp();     
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Listar()
	{
		try
		{
			$stm = $this->pdo->prepare("SELECT * FROM alumnos ORDER BY id DESC");
			$stm->execute();
			return $stm->fetchAll(PDO::FETCH_OBJ);
		}
		catch(Exception $e)
		{
			die($e->getMessage());
		}
	}

	public function Obtener($id)
	{
		try 
		{
			$stm = $this->pdo->prepare("SELECT * FROM alumnos WHERE id = ?");
			$stm->execute(array($id));
			return $stm->fetch(PDO::FETCH_OBJ);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Eliminar($id)
	{
		try 
		{
			$stm = $this->pdo->prepare("DELETE FROM alumnos WHERE id = ?");
			$stm->execute(array($id));
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Actualizar($data)
	{
		try 
		{
			$sql = "UPDATE alumnos SET 
						Nombre          = ?, 
						Apellido        = ?,
                        Correo          = ?,
						Sexo            = ?, 
						FechaNacimiento = ?
					WHERE id = ?";

			// BUG CORREGIDO: el orden de parámetros ahora coincide con la query
			$this->pdo->prepare($sql)
			     ->execute(
				    array(
                        $data->Nombre,      // Nombre
                        $data->Apellido,    // Apellido
                        $data->Correo,      // Correo
                        $data->Sexo,        // Sexo
                        $data->FechaNacimiento, // FechaNacimiento
                        $data->id           // WHERE id
					)
				);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}

	public function Registrar(Alumno $data)
	{
		try 
		{
			$sql = "INSERT INTO alumnos (Nombre, Apellido, Correo, Sexo, FechaNacimiento, FechaRegistro) 
			        VALUES (?, ?, ?, ?, ?, ?)";

			$this->pdo->prepare($sql)
			     ->execute(
					array(
                        $data->Nombre,
                        $data->Apellido,
                        $data->Correo, 
                        $data->Sexo,
                        $data->FechaNacimiento,
                        date('Y-m-d')
                    )
				);
		} catch (Exception $e) 
		{
			die($e->getMessage());
		}
	}
}
