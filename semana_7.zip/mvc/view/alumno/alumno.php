<h1 class="page-header">Alumnos</h1>

<div class="well well-sm text-right">
    <a class="btn btn-primary" href="?c=Alumno&a=Crud">
        <span class="glyphicon glyphicon-plus"></span> Nuevo alumno
    </a>
</div>

<?php $alumnos = $this->model->Listar(); ?>

<?php if(empty($alumnos)): ?>
    <div class="alert alert-info">No hay alumnos registrados aún.</div>
<?php else: ?>
<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th style="width:180px;">Nombre</th>
            <th>Apellido</th>
            <th>Correo</th>
            <th style="width:120px;">Sexo</th>
            <th style="width:130px;">Nacimiento</th>
            <th style="width:80px;" class="text-center">Editar</th>
            <th style="width:80px;" class="text-center">Eliminar</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($alumnos as $r): ?>
        <tr>
            <td><?php echo htmlspecialchars($r->Nombre); ?></td>
            <td><?php echo htmlspecialchars($r->Apellido); ?></td>
            <td><?php echo htmlspecialchars($r->Correo); ?></td>
            <td>
                <?php if($r->Sexo == 1): ?>
                    <span class="label label-primary">Masculino</span>
                <?php else: ?>
                    <span class="label label-danger">Femenino</span>
                <?php endif; ?>
            </td>
            <td><?php echo htmlspecialchars($r->FechaNacimiento); ?></td>
            <td class="text-center">
                <a class="btn btn-xs btn-warning" href="?c=Alumno&a=Crud&id=<?php echo (int)$r->id; ?>">
                    <span class="glyphicon glyphicon-pencil"></span>
                </a>
            </td>
            <td class="text-center">
                <a class="btn btn-xs btn-danger"
                   onclick="return confirm('¿Seguro que desea eliminar a <?php echo htmlspecialchars(addslashes($r->Nombre)); ?>?');"
                   href="?c=Alumno&a=Eliminar&id=<?php echo (int)$r->id; ?>">
                    <span class="glyphicon glyphicon-trash"></span>
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>
