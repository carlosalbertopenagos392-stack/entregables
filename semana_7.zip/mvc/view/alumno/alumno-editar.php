<h1 class="page-header">
    <?php echo ($alm->id != null) ? htmlspecialchars($alm->Nombre . ' ' . $alm->Apellido) : 'Nuevo Alumno'; ?>
</h1>

<ol class="breadcrumb">
  <li><a href="?c=Alumno">Alumnos</a></li>
  <li class="active"><?php echo ($alm->id != null) ? htmlspecialchars($alm->Nombre) : 'Nuevo Registro'; ?></li>
</ol>

<form id="frm-alumno" action="?c=Alumno&a=Guardar" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo (int)$alm->id; ?>" />
    
    <div class="form-group">
        <label>Nombre</label>
        <input type="text" name="Nombre"
               value="<?php echo htmlspecialchars($alm->Nombre ?? ''); ?>"
               class="form-control"
               placeholder="Ingrese el nombre"
               data-validacion-tipo="requerido|min:2" />
    </div>
    
    <div class="form-group">
        <label>Apellido</label>
        <input type="text" name="Apellido"
               value="<?php echo htmlspecialchars($alm->Apellido ?? ''); ?>"
               class="form-control"
               placeholder="Ingrese el apellido"
               data-validacion-tipo="requerido|min:2" />
        <!-- BUG CORREGIDO: validación mínima era 10, ahora es 2 (más razonable) -->
    </div>
    
    <div class="form-group">
        <label>Correo electrónico</label>
        <input type="text" name="Correo"
               value="<?php echo htmlspecialchars($alm->Correo ?? ''); ?>"
               class="form-control"
               placeholder="ejemplo@correo.com"
               data-validacion-tipo="requerido|email" />
    </div>
    
    <div class="form-group">
        <label>Sexo</label>
        <select name="Sexo" class="form-control">
            <option value="">-- Seleccione --</option>
            <option <?php echo ($alm->Sexo == 1) ? 'selected' : ''; ?> value="1">Masculino</option>
            <option <?php echo ($alm->Sexo == 2) ? 'selected' : ''; ?> value="2">Femenino</option>
        </select>
    </div>
    
    <div class="form-group">
        <label>Fecha de nacimiento</label>
        <!-- MEJORA: wrapper con ícono de calendario -->
        <div class="input-fecha-wrapper">
            <input readonly type="text"
                   name="FechaNacimiento"
                   value="<?php echo htmlspecialchars($alm->FechaNacimiento ?? ''); ?>"
                   class="form-control datepicker"
                   placeholder="Seleccione la fecha"
                   data-validacion-tipo="requerido" />
            <span class="icono-calendario glyphicon glyphicon-calendar"></span>
        </div>
    </div>
    
    <hr />
    
    <div class="text-right">
        <a href="?c=Alumno" class="btn btn-default">Cancelar</a>
        <button type="submit" class="btn btn-success">
            <span class="glyphicon glyphicon-floppy-disk"></span> Guardar
        </button>
    </div>
</form>

<script>
    $(document).ready(function(){
        $("#frm-alumno").submit(function(){
            return $(this).validate();
        });
    });
</script>
