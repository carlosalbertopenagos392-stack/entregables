<!DOCTYPE html>
<html lang="es">
	<head>
		<title>Gestión de Alumnos</title>
        
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
        <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css" />
        <link rel="stylesheet" href="assets/js/jquery-ui/jquery-ui.min.css" />
        <link rel="stylesheet" href="assets/css/style.css" />
        
        <!-- BUG CORREGIDO: cambiado HTTP → HTTPS para que no sea bloqueado -->
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
	</head>
    <body>
        
    <div class="container">
